import { Router, type IRouter } from "express";
import { GetNeocitiesFilesResponse } from "@workspace/api-zod";
import { requireSiteSession } from "../lib/site-sessions";

const router: IRouter = Router();
const SITE_URL = "https://szopikpraczekyt-nowastrona.neocities.org/";
const NEOCITIES_LIST_URL = "https://neocities.org/api/list";
const IMAGE_EXTENSIONS = new Set([
  "avif",
  "bmp",
  "gif",
  "ico",
  "jpeg",
  "jpg",
  "png",
  "svg",
  "webp",
]);
const DOCUMENT_EXTENSIONS = new Set([
  "csv",
  "doc",
  "docx",
  "md",
  "odt",
  "pdf",
  "ppt",
  "pptx",
  "rtf",
  "txt",
  "xls",
  "xlsx",
]);

type NeocitiesFileEntry = {
  path: string;
  is_directory: boolean;
  size?: number;
  updated_at?: string;
};

type NeocitiesListResponse = {
  result: string;
  files?: NeocitiesFileEntry[];
};

function getCategory(extension: string) {
  if (IMAGE_EXTENSIONS.has(extension)) return "image";
  if (extension === "html" || extension === "htm") return "html";
  if (extension === "css") return "css";
  if (["js", "mjs", "cjs"].includes(extension)) return "javascript";
  if (DOCUMENT_EXTENSIONS.has(extension)) return "document";
  return "other";
}

function getUpdatedAt(value: string | undefined): Date | null {
  if (!value) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

router.get("/neocities/files", requireSiteSession, async (req, res): Promise<void> => {
  const apiKey = process.env.NEOCITIES_API_KEY;

  if (!apiKey) {
    res.status(503).json({
      error:
        "Brak klucza API Neocities po stronie serwera. Dodaj NEOCITIES_API_KEY w sekretach projektu.",
    });
    return;
  }

  try {
    const upstreamResponse = await fetch(NEOCITIES_LIST_URL, {
      headers: { Authorization: `Bearer ${apiKey}` },
      signal: AbortSignal.timeout(15_000),
    });

    if (!upstreamResponse.ok) {
      req.log.warn(
        { upstreamStatus: upstreamResponse.status },
        "Neocities file listing request failed",
      );
      res.status(502).json({
        error:
          upstreamResponse.status === 403
            ? "Neocities odrzuciło klucz API. Sprawdź sekret NEOCITIES_API_KEY."
            : "Nie udało się pobrać plików z Neocities. Spróbuj ponownie za chwilę.",
      });
      return;
    }

    const payload = (await upstreamResponse.json()) as NeocitiesListResponse;
    if (payload.result !== "success" || !Array.isArray(payload.files)) {
      req.log.warn("Neocities returned an unexpected file listing");
      res.status(502).json({
        error:
          "Neocities zwróciło nieprawidłową listę plików. Spróbuj ponownie za chwilę.",
      });
      return;
    }

    const files = payload.files
      .filter((file) => !file.is_directory && typeof file.path === "string")
      .map((file) => {
        const path = file.path.replace(/^\/+/, "");
        const name = path.split("/").pop() || path;
        const dotIndex = name.lastIndexOf(".");
        const extension = dotIndex > 0 ? name.slice(dotIndex + 1).toLowerCase() : "";
        const encodedPath = path.split("/").map(encodeURIComponent).join("/");

        return {
          path,
          name,
          extension,
          category: getCategory(extension),
          size:
            typeof file.size === "number" && Number.isFinite(file.size)
              ? Math.max(0, Math.trunc(file.size))
              : null,
          updatedAt: getUpdatedAt(file.updated_at),
          url: new URL(encodedPath, SITE_URL).toString(),
        };
      });

    const response = GetNeocitiesFilesResponse.parse({
      siteUrl: SITE_URL,
      fetchedAt: new Date(),
      totalFiles: files.length,
      files,
    });

    res.json(response);
  } catch (error) {
    req.log.error({ err: error }, "Failed to retrieve Neocities files");
    res.status(502).json({
      error:
        "Nie udało się połączyć z Neocities. Sprawdź połączenie i spróbuj ponownie.",
    });
  }
});

export default router;
