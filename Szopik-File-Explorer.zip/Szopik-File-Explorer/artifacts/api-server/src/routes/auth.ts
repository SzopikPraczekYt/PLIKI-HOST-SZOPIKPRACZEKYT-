import { createHash, timingSafeEqual } from "node:crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  CreatePasswordSessionBody,
  GetAuthSessionResponse,
} from "@workspace/api-zod";
import {
  clearSiteSessionCookie,
  createSiteSession,
  getSiteSession,
  revokeSiteSession,
  setSiteSessionCookie,
} from "../lib/site-sessions";

const router: IRouter = Router();
const MAX_FAILED_ATTEMPTS = 5;
const ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const MAX_TRACKED_ADDRESSES = 10_000;

type AttemptWindow = { failures: number; resetsAt: number };
const attemptsByAddress = new Map<string, AttemptWindow>();

function addressKey(req: Request): string {
  const ipAddress = req.ip || req.socket.remoteAddress || "unknown";
  return createHash("sha256").update(ipAddress).digest("hex");
}

function secondsUntilUnlocked(key: string, now = Date.now()): number {
  const window = attemptsByAddress.get(key);
  if (!window) return 0;
  if (window.resetsAt <= now) {
    attemptsByAddress.delete(key);
    return 0;
  }
  if (window.failures < MAX_FAILED_ATTEMPTS) return 0;
  return Math.ceil((window.resetsAt - now) / 1000);
}

function recordFailedAttempt(key: string, now = Date.now()): void {
  let window = attemptsByAddress.get(key);
  if (!window || window.resetsAt <= now) {
    window = { failures: 0, resetsAt: now + ATTEMPT_WINDOW_MS };
  }
  window.failures += 1;
  attemptsByAddress.delete(key);
  attemptsByAddress.set(key, window);

  if (attemptsByAddress.size > MAX_TRACKED_ADDRESSES) {
    const oldestKey = attemptsByAddress.keys().next().value;
    if (typeof oldestKey === "string") attemptsByAddress.delete(oldestKey);
  }
}

function passwordMatches(provided: string, configured: string): boolean {
  const providedDigest = createHash("sha256").update(provided).digest();
  const configuredDigest = createHash("sha256").update(configured).digest();
  return timingSafeEqual(providedDigest, configuredDigest);
}

function isSameOriginRequest(req: Request): boolean {
  const fetchSite = req.get("sec-fetch-site");
  if (fetchSite && fetchSite !== "same-origin" && fetchSite !== "none") {
    return false;
  }

  const origin = req.get("origin");
  if (!origin) return true;

  const host = req.get("host");
  if (!host) return false;
  try {
    return new URL(origin).origin === `${req.protocol}://${host}`;
  } catch {
    return false;
  }
}

function setNoStore(res: Response): void {
  res.setHeader("Cache-Control", "no-store");
}

router.get("/auth/session", (req, res): void => {
  setNoStore(res);
  const session = getSiteSession(req);
  res.json(
    GetAuthSessionResponse.parse({
      authenticated: Boolean(session),
      expiresAt: session ? new Date(session.expiresAt).toISOString() : null,
    }),
  );
});

router.post("/auth/login", (req, res): void => {
  setNoStore(res);
  if (!isSameOriginRequest(req)) {
    res.status(403).json({ error: "Niedozwolone żądanie." });
    return;
  }

  const address = addressKey(req);
  const retryAfter = secondsUntilUnlocked(address);
  if (retryAfter > 0) {
    res.setHeader("Retry-After", retryAfter);
    res.status(429).json({
      error: `Zbyt wiele prób logowania. Spróbuj ponownie za ${Math.ceil(retryAfter / 60)} min.`,
    });
    return;
  }

  const configuredPassword = process.env.SITE_PASSWORD;
  if (!configuredPassword || !process.env.SESSION_SECRET) {
    req.log.error("Site login is missing required Replit Secrets");
    res.status(503).json({
      error: "Logowanie nie jest skonfigurowane. Dodaj SITE_PASSWORD w Replit Secrets.",
    });
    return;
  }

  const parsed = CreatePasswordSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Wpisz hasło." });
    return;
  }

  if (!passwordMatches(parsed.data.password, configuredPassword)) {
    recordFailedAttempt(address);
    res.status(401).json({ error: "Nieprawidłowe hasło" });
    return;
  }

  attemptsByAddress.delete(address);
  revokeSiteSession(req);
  const session = createSiteSession();
  if (!session) {
    req.log.error("Site login could not create a session");
    res.status(503).json({
      error: "Logowanie jest chwilowo niedostępne. Spróbuj ponownie później.",
    });
    return;
  }

  setSiteSessionCookie(req, res, session.token);
  res.json(
    GetAuthSessionResponse.parse({
      authenticated: true,
      expiresAt: new Date(session.expiresAt).toISOString(),
    }),
  );
});

router.post("/auth/logout", (req, res): void => {
  setNoStore(res);
  if (!isSameOriginRequest(req)) {
    res.status(403).json({ error: "Niedozwolone żądanie." });
    return;
  }

  revokeSiteSession(req);
  clearSiteSessionCookie(req, res);
  res.sendStatus(204);
});

const attemptsCleanupTimer = setInterval(() => {
  const now = Date.now();
  for (const [key, window] of attemptsByAddress) {
    if (window.resetsAt <= now) attemptsByAddress.delete(key);
  }
}, ATTEMPT_WINDOW_MS);
attemptsCleanupTimer.unref();

export default router;
