import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import neocitiesRouter from "./neocities";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(neocitiesRouter);

export default router;
