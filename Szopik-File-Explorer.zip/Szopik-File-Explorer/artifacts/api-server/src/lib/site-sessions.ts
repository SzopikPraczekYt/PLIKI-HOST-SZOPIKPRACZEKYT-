import { createHmac, randomBytes } from "node:crypto";
import type { CookieOptions, Request, RequestHandler, Response } from "express";

export const SESSION_COOKIE_NAME = "szopik_session";
export const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

type StoredSession = { expiresAt: number };

const sessions = new Map<string, StoredSession>();

function sessionKey(token: string): string | null {
  const secret = process.env.SESSION_SECRET;
  if (!secret) return null;
  return createHmac("sha256", secret).update(token).digest("hex");
}

function cookieOptions(req: Request): CookieOptions {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production" || req.secure,
    sameSite: "lax",
    path: "/",
  };
}

export function createSiteSession():
  | { token: string; expiresAt: number }
  | null {
  const token = randomBytes(32).toString("base64url");
  const key = sessionKey(token);
  if (!key) return null;

  const expiresAt = Date.now() + SESSION_TTL_MS;
  sessions.set(key, { expiresAt });
  return { token, expiresAt };
}

export function getSiteSession(req: Request): StoredSession | null {
  const token: unknown = req.cookies?.[SESSION_COOKIE_NAME];
  if (typeof token !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(token)) {
    return null;
  }

  const key = sessionKey(token);
  if (!key) return null;

  const session = sessions.get(key);
  if (!session) return null;
  if (session.expiresAt <= Date.now()) {
    sessions.delete(key);
    return null;
  }
  return session;
}

export function revokeSiteSession(req: Request): void {
  const token: unknown = req.cookies?.[SESSION_COOKIE_NAME];
  if (typeof token !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(token)) return;

  const key = sessionKey(token);
  if (key) sessions.delete(key);
}

export function setSiteSessionCookie(
  req: Request,
  res: Response,
  token: string,
): void {
  res.cookie(SESSION_COOKIE_NAME, token, {
    ...cookieOptions(req),
    maxAge: SESSION_TTL_MS,
  });
}

export function clearSiteSessionCookie(req: Request, res: Response): void {
  res.clearCookie(SESSION_COOKIE_NAME, cookieOptions(req));
}

export const requireSiteSession: RequestHandler = (req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  if (!getSiteSession(req)) {
    res.status(401).json({
      error: "Sesja wygasła lub nie istnieje. Zaloguj się ponownie.",
    });
    return;
  }
  next();
};

const cleanupTimer = setInterval(() => {
  const now = Date.now();
  for (const [key, session] of sessions) {
    if (session.expiresAt <= now) sessions.delete(key);
  }
}, 5 * 60 * 1000);
cleanupTimer.unref();
