import { useCallback, useEffect, useState, type FormEvent } from 'react';
import {
  createPasswordSession,
  endPasswordSession,
  getAuthSession,
} from '@workspace/api-client-react';
import type { AuthSession } from '@workspace/api-client-react';
import Home from '@/pages/home';
import '@/pages/home.css';

type AuthState = 'checking' | 'signed-out' | 'signed-in';

function expirationTime(session: AuthSession): number | null {
  if (!session.authenticated || !session.expiresAt) return null;
  const value = Date.parse(String(session.expiresAt));
  return Number.isFinite(value) && value > Date.now() ? value : null;
}

function errorDetails(error: unknown): { status?: number; message?: string } {
  if (!error || typeof error !== 'object') return {};
  const candidate = error as { status?: unknown; data?: unknown };
  const status = typeof candidate.status === 'number' ? candidate.status : undefined;
  const data = candidate.data;
  const message =
    data && typeof data === 'object' && 'error' in data && typeof data.error === 'string'
      ? data.error
      : undefined;
  return { status, message };
}

function LoginForm({ onAuthenticated }: { onAuthenticated: (expiresAt: number) => void }) {
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessage('');
    setIsSubmitting(true);

    try {
      const session = await createPasswordSession(
        { password },
        { credentials: 'same-origin', cache: 'no-store' },
      );
      const expiresAt = expirationTime(session);
      if (!expiresAt) {
        setMessage('Nie udało się rozpocząć sesji. Spróbuj ponownie.');
        return;
      }
      setPassword('');
      onAuthenticated(expiresAt);
    } catch (error) {
      const details = errorDetails(error);
      setMessage(details.status === 401 ? 'Nieprawidłowe hasło' : details.message || 'Logowanie nie powiodło się. Spróbuj ponownie.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="file-explorer login-page">
      <h1 className="page-title">SzopikPraczekYT — Logowanie</h1>
      <form className="login-form" onSubmit={handleSubmit}>
        <input
          className="visually-hidden"
          type="text"
          name="username"
          value="szopikpraczekyt"
          autoComplete="username"
          tabIndex={-1}
          aria-hidden="true"
          readOnly
        />
        <label className="visually-hidden" htmlFor="site-password">Hasło</label>
        <input
          id="site-password"
          className="search-input"
          type="password"
          name="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          autoComplete="current-password"
          placeholder="Hasło"
          maxLength={1024}
          required
          data-testid="input-password"
        />
        {message && <p className="login-message" role="alert" data-testid="login-error">{message}</p>}
        <button className="login-button" type="submit" disabled={isSubmitting} data-testid="button-login">
          {isSubmitting ? 'Logowanie...' : 'Zaloguj się'}
        </button>
      </form>
    </main>
  );
}

export default function PasswordGate() {
  const [authState, setAuthState] = useState<AuthState>('checking');
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [logoutMessage, setLogoutMessage] = useState('');

  useEffect(() => {
    document.title = authState === 'signed-in'
      ? 'SzopikPraczekYT — Pliki'
      : 'SzopikPraczekYT — Logowanie';
  }, [authState]);

  const signOutLocally = useCallback(() => {
    setAuthState('signed-out');
    setExpiresAt(null);
    setLogoutMessage('');
  }, []);

  const acceptSession = useCallback((sessionExpiry: number) => {
    setExpiresAt(sessionExpiry);
    setAuthState('signed-in');
    setLogoutMessage('');
  }, []);

  useEffect(() => {
    let mounted = true;
    getAuthSession({ credentials: 'same-origin', cache: 'no-store' })
      .then((session) => {
        if (!mounted) return;
        const expiry = expirationTime(session);
        if (expiry) acceptSession(expiry);
        else signOutLocally();
      })
      .catch(() => {
        if (mounted) signOutLocally();
      });
    return () => {
      mounted = false;
    };
  }, [acceptSession, signOutLocally]);

  useEffect(() => {
    if (authState !== 'signed-in' || expiresAt === null) return;
    const timeout = window.setTimeout(
      signOutLocally,
      Math.max(0, expiresAt - Date.now()),
    );
    return () => window.clearTimeout(timeout);
  }, [authState, expiresAt, signOutLocally]);

  const logout = useCallback(async () => {
    setLogoutMessage('');
    try {
      await endPasswordSession({ credentials: 'same-origin', cache: 'no-store' });
      signOutLocally();
    } catch {
      setLogoutMessage('Nie udało się wylogować. Spróbuj ponownie.');
    }
  }, [signOutLocally]);

  if (authState === 'checking') {
    return <main className="file-explorer login-page"><p className="list-message">Sprawdzanie sesji...</p></main>;
  }

  if (authState === 'signed-out') {
    return <LoginForm onAuthenticated={acceptSession} />;
  }

  return (
    <Home
      logoutMessage={logoutMessage}
      onLogout={logout}
      onSessionExpired={signOutLocally}
    />
  );
}
