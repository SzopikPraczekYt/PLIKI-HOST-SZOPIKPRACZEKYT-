import { useEffect, useMemo, useState } from 'react';
import { getGetNeocitiesFilesQueryKey, useGetNeocitiesFiles } from '@workspace/api-client-react';
import type { NeocitiesFile } from '@workspace/api-client-react';
import './home.css';

type FolderEntry = {
  kind: 'folder';
  name: string;
  path: string;
  parentPath: string;
};

type FileExplorerIndex = {
  folders: FolderEntry[];
  filesByFolder: Map<string, NeocitiesFile[]>;
};

function fileName(file: NeocitiesFile) {
  return file.name || file.path.split('/').filter(Boolean).at(-1) || file.path;
}

function parentPath(path: string) {
  const separator = path.lastIndexOf('/');
  return separator < 0 ? '' : path.slice(0, separator);
}

function fileIcon(file: NeocitiesFile) {
  switch (file.category) {
    case 'image':
      return '🖼️';
    case 'css':
      return '🎨';
    case 'javascript':
      return '📜';
    default:
      return '📄';
  }
}

type HomeProps = {
  logoutMessage: string;
  onLogout: () => Promise<void>;
  onSessionExpired: () => void;
};

export default function Home({ logoutMessage, onLogout, onSessionExpired }: HomeProps) {
  const { data, isLoading, isError, error } = useGetNeocitiesFiles({
    query: {
      queryKey: getGetNeocitiesFilesQueryKey(),
      refetchInterval: 10 * 60 * 1000,
      refetchOnMount: false,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
      retry: false,
    },
  });
  const [search, setSearch] = useState('');
  const [currentPath, setCurrentPath] = useState('');
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const apiErrorStatus = (error as { status?: number } | undefined)?.status;
  useEffect(() => {
    if (apiErrorStatus === 401) onSessionExpired();
  }, [apiErrorStatus, onSessionExpired]);

  const index = useMemo<FileExplorerIndex>(() => {
    const folders = new Map<string, FolderEntry>();
    const filesByFolder = new Map<string, NeocitiesFile[]>();

    for (const file of data?.files ?? []) {
      const segments = file.path.split('/').filter(Boolean);
      const leafName = segments.pop();
      if (!leafName) continue;

      let parent = '';
      for (const name of segments) {
        const path = parent ? `${parent}/${name}` : name;
        if (!folders.has(path)) {
          folders.set(path, { kind: 'folder', name, path, parentPath: parent });
        }
        parent = path;
      }

      const siblings = filesByFolder.get(parent) ?? [];
      siblings.push(file);
      filesByFolder.set(parent, siblings);
    }

    return { folders: [...folders.values()], filesByFolder };
  }, [data?.files]);

  const normalizedSearch = search.trim().toLocaleLowerCase('pl-PL');
  const visibleFolders = normalizedSearch
    ? index.folders.filter((folder) => folder.name.toLocaleLowerCase('pl-PL').includes(normalizedSearch))
    : index.folders.filter((folder) => folder.parentPath === currentPath);
  const visibleFiles = normalizedSearch
    ? (data?.files ?? []).filter((file) => fileName(file).toLocaleLowerCase('pl-PL').includes(normalizedSearch))
    : index.filesByFolder.get(currentPath) ?? [];
  const breadcrumbs = currentPath.split('/').filter(Boolean).map((name, position, parts) => ({
    name,
    path: parts.slice(0, position + 1).join('/'),
  }));

  const goToFolder = (path: string) => {
    setCurrentPath(path);
    setSearch('');
  };

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await onLogout();
    } finally {
      setIsLoggingOut(false);
    }
  };

  return (
    <main className="file-explorer">
      <header className="explorer-heading">
        <h1 className="page-title">SzopikPraczekYT — Pliki</h1>
        <button className="logout-button" type="button" onClick={() => void handleLogout()} disabled={isLoggingOut} data-testid="button-logout">
          {isLoggingOut ? 'Wylogowywanie...' : 'Wyloguj'}
        </button>
      </header>
      {logoutMessage && <p className="logout-message" role="alert">{logoutMessage}</p>}

      <label className="search-label">
        <span className="visually-hidden">Szukaj plików i folderów</span>
        <input
          className="search-input"
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Szukaj plików i folderów..."
          autoComplete="off"
          data-testid="input-search"
        />
      </label>

      <nav className="breadcrumbs" aria-label="Ścieżka folderu">
        <button className="breadcrumb-link" type="button" onClick={() => goToFolder('')} data-testid="breadcrumb-home">
          Strona główna
        </button>
        {breadcrumbs.map((crumb, index) => {
          const current = index === breadcrumbs.length - 1;
          return (
            <span className="breadcrumb-part" key={crumb.path}>
              <span className="breadcrumb-separator" aria-hidden="true">/</span>
              {current ? (
                <span aria-current="location">{crumb.name}</span>
              ) : (
                <button
                  className="breadcrumb-link"
                  type="button"
                  onClick={() => goToFolder(crumb.path)}
                  data-testid={`breadcrumb-${crumb.path}`}
                >
                  {crumb.name}
                </button>
              )}
            </span>
          );
        })}
      </nav>

      {isLoading ? (
        <p className="list-message" role="status" data-testid="status-loading">Wczytywanie plików...</p>
      ) : isError ? (
        <p className="list-message" role="alert" data-testid="status-error">
          {error?.data?.error || 'Nie udało się wczytać plików. Spróbuj ponownie później.'}
        </p>
      ) : visibleFolders.length === 0 && visibleFiles.length === 0 ? (
        <p className="list-message" data-testid="status-empty">Nie znaleziono plików ani folderów</p>
      ) : (
        <ul className="file-list" aria-live="polite" data-testid="list-files">
          {visibleFolders.map((folder) => (
            <li className="file-row" key={`folder:${folder.path}`}>
              <button
                className="entry entry-button"
                type="button"
                onClick={() => goToFolder(folder.path)}
                aria-label={`Otwórz folder ${folder.name}`}
                data-testid={`folder-${folder.path}`}
              >
                <span className="entry-icon" aria-hidden="true">📁</span>
                <span className="entry-name">{folder.name}</span>
                {normalizedSearch && <span className="entry-path">{folder.path}</span>}
              </button>
            </li>
          ))}
          {visibleFiles.map((file) => (
            <li className="file-row" key={`file:${file.path}`}>
              <a
                className="entry entry-link"
                href={file.url}
                target="_blank"
                rel="noreferrer"
                data-testid={`file-${file.path}`}
              >
                <span className="entry-icon" aria-hidden="true">{fileIcon(file)}</span>
                <span className="entry-name">{fileName(file)}</span>
                {normalizedSearch && <span className="entry-path">{parentPath(file.path) || 'Strona główna'}</span>}
              </a>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
